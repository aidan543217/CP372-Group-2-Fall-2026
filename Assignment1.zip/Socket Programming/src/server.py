"""
-------------------------------------------------------
[This is the server function for a chat room]
-------------------------------------------------------
__updated__ = "2026-10-20"
-------------------------------------------------------
"""
# Imports
import socket
import select
# Constants
HEADER_LENGTH = 20
IP = "127.0.0.1"
PORT = 100


# Server socket setup
ssocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM) # ADDRESS FAMILY INTERNET
ssocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) # this makes it so we can reuse the same port without having to change it

# bind the socket
ssocket.bind((IP,PORT))
ssocket.listen() # listen to the socket for updates

s_list = [ssocket] # store the sockets

clients = {} # store where client sockets are and user data is the value

# The server recieves messages and the client sends them. Thus, listening is required.

def recieve(csocket):
    try:
        messageheader = csocket.recv(HEADER_LENGTH) # recieve the header
        
        if not len(messageheader): # client closed connection if didnt get any data
            return
        messagelength = int(messageheader.decode("utf-8").strip())
        return {"header": messageheader, "data": csocket.recv(messagelength)}
    
    except:
        pass